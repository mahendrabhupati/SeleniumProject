$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/resources/feature/featureFile.feature");
formatter.feature({
  "line": 2,
  "name": "OrangeHRM website",
  "description": "",
  "id": "orangehrm-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@DemoOrangeHRM"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "",
  "description": "Login in to demo blaze website",
  "id": "orangehrm-website;",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@Tc_1"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "user launched the chromebrowser",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "user open the Demoblaze website",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "user enters the username and password",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "clicks on login button",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "validation of homepage",
  "keyword": "Then "
});
formatter.match({
  "location": "Login_SD.user_launched_the_chromebrowser()"
});
});