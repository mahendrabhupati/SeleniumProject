package stepDefinitions;

import java.io.IOException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ValidSearch;

public class ValidSearch_SD {
	ValidSearch page3 = new ValidSearch();
	@Given("^launch the chrome Browser$")
	public void launch_the_chrome_Browser()  {
	    // Write code here that turns the phrase above into concrete actions
	   page3.browserLaunch("chrome");
	}

	@When("^Login to the OrangeHRM Home Page and navigate to the Directory Tab$")
	public void login_to_the_OrangeHRM_Home_Page_and_navigate_to_the_Directory_Tab() {
	    // Write code here that turns the phrase above into concrete actions
	    page3.homePage("https://opensource-demo.orangehrmlive.com/");
	    page3.login();
	}

	@Then("^Enter the valid data$")
	public void enter_the_valid_data() throws Throwable {
	    // enter all the valid data in respective fields
	    page3.validSearchOperation();
	}

	@And("^Click on the Search button$")
	public void click_on_the_Search_button()  {
	    // Clicking on the search button to perform operation 
	    page3.searchButton();
	}

	@Then("^Validation of the functionality$")
	public void validation_of_the_functionality() throws IOException  {
	    // validating the valid search functionity
		page3.getScreenshot();
	    page3.close();
	}
}
