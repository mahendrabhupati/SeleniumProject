package stepDefinitions;

import java.io.IOException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Directory;

public class Directory_SD {
	Directory page2 = new Directory();
	@Given("^Launch the chrome browser$")
	public void launch_the_chrome_browser() {
		// Launching the chrome browser
		page2.browserLaunch("chrome");
	}

	@When("^Open the OrangeHRM Home Page and login to the application$")
	public void open_the_OrangeHRM_Home_Page_and_login_to_the_application() {
		// open homepage and login to the website
		page2.demoblaze_homePage("https://opensource-demo.orangehrmlive.com/");
	}


	@Then("^Click on the Directory Tab$")
	public void click_on_the_Directory_Tab() {
		// clicking the Directory Tab
		page2.login();
		page2.DirectoryTab();
	}

	@And("^Validate the click functonality$")
	public void validate_the_click_functonality() throws IOException {
		// Validating the DirectoryaTab
		page2.DirectoryTabValidation();
		page2.close();
	}
}
