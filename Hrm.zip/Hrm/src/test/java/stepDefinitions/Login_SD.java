package stepDefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import freemarker.core.ParseException;
import pages.Login;

public class Login_SD {
	Login page1 = new Login();
	@Given("^user launched the chromebrowser$")
	public void user_launched_the_chromebrowser()  {
	    // launching the required  browser 
	    page1.browserLaunch("chrome");
	}

	@When("^user open the Demoblaze website$")
	public void user_open_the_Demoblaze_website()  {
	   // After launching the browser user enters the demo blaze website
	    page1.homePage("https://opensource-demo.orangehrmlive.com/");
	}

	@Then("^user enters the username and password$")
	public void user_enters_the_username_and_password()  {
	    // User enters the valid credentials
	    page1.login();
	}

	@And("^clicks on login button$")
	public void clicks_on_login_button() throws Throwable {
	    // After entering valid credentials and clicking on the submit button
	    page1.userclick();
	}
	@Then("^validation of homepage$")
	public void validation_of_homepage() throws Throwable {
	    // validating the home page
		page1.validation();
		page1.close();
	}
}
