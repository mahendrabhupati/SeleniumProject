package stepDefinitions;

import java.io.IOException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.InvalidSearch;

public class InvalidSearch_SD {
	InvalidSearch page4 = new InvalidSearch();

	@Given("^launch the chromeBrowser$")
	public void launch_the_chromeBrowser() {
		// launch the browser
		page4.browserLaunch("chrome");
	}

	@When("^Login to the OrangeHRM Home Page and navigate to the DirectoryTab$")
	public void login_to_the_OrangeHRM_Home_Page_and_navigate_to_the_DirectoryTab() {
		// enter the valid credentials to land on a home page
		page4.homePage("https://opensource-demo.orangehrmlive.com/");
		page4.login();
	}

	@Then("^Enter the invalid data$")
	public void enter_the_invalid_data() {
		// enter the invalid data in respective fields
		page4.InvalidSearchOperation();
	}

	@And("^Click on the Search Button$")
	public void click_on_the_Search_Button() {
		page4.searchButton();
	}

	@Then("^Validation of the Functionality$")
	public void validation_of_the_Functionality() throws IOException {

		page4.getScreenshot();
		page4.close();
	}

}
