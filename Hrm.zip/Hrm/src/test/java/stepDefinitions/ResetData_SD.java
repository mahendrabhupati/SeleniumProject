package stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ResetData;

public class ResetData_SD {
	ResetData page5 = new ResetData();
	@Given("^launch the ChromeBrowser$")
	public void launch_the_ChromeBrowser()  {
	    //Launch the browser
		page5.browserLaunch("chrome");
	 
	}

	@When("^Login to the OrangeHRM Home Page and Navigate to the DirectoryTab$")
	public void login_to_the_OrangeHRM_Home_Page_and_Navigate_to_the_DirectoryTab(){
	    // enter the valid credentials to land the home page
		page5.homePage("https://opensource-demo.orangehrmlive.com/");
		page5.login();
	}

	@Then("^Enter the data$")
	public void enter_the_data()  {
	    // Enter the data required fields
		page5.getData();
		
	
	}

	@Then("^Validation of the Reset Functionality$")
	public void validation_of_the_Reset_Functionality()  {
	    // checking the reset functonlaity
		page5.resetButton();
		page5.close();
	    
	}
}
