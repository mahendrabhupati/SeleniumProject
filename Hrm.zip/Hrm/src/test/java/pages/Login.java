package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Login {
	WebDriver driver;
	By username = By.id("txtUsername");
	By password = By.id("txtPassword");
	By login = By.id("btnLogin");

	public void browserLaunch(String browserName) {
		// multi browser selectio method
		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("Explorer")) {
			System.setProperty("webdriver.ie.driver", "drivers/ie.exe");
			driver = new InternetExplorerDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://google.com");
	}

	/*
	 * public void usernamepassword(int a) throws IOException, InterruptedException
	 * { ValidExcelUtility ex = new ValidExcelUtility();
	 * driver.findElement(By.id("Username")).sendKeys(ex.excel_username(a));
	 * driver.findElement(By.id("Password")).sendKeys(ex.excel_password(a));
	 * WebElement d = driver.findElement(By.xpath(
	 * "//*[@id=\"logInModal\"]//div//div//div[3]//button[2]")); d.click(); }
	 * 
	 */

	public void homePage(String url) {
		// navigating to the homepage
		driver.get(url);
		System.out.println(driver.getTitle());

	}

	public void login() {
		// entering valid credentials
		driver.findElement(username).sendKeys("Admin");
		driver.findElement(password).sendKeys("admin123");

	}

	public void userclick() {
		WebElement d = driver.findElement(By.id("btnLogin"));
		d.click();

	}

	public void validation() {
		// Validating the homepage
		String ActualTitle = driver.getTitle();
		String expectedTitle = "orangeHRM";
		if (ActualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("Title Matched");
		else
			System.out.println("Title didn't match");
	}

	public void close() {
		driver.quit();
	}
}
