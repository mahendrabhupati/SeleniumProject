package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class InvalidSearch {
	WebDriver driver;
	By username = By.id("txtUsername");
	By password = By.id("txtPassword");
	By login = By.id("btnLogin");
	By invalid_name = By.name("searchDirectory[emp_name][empName]");
	By searchButton = By.id("searchBtn");
	By DirectoryTab = By.xpath("//*[@id=\"menu_directory_viewDirectory\"]/b");
	By Result = By.xpath("//*[@id=\"content\"]/div[2]/div[2]");

	public void browserLaunch(String browserName) {
		// multi browser selectio method
		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("Explorer")) {
			System.setProperty("webdriver.ie.driver", "drivers/ie.exe");
			driver = new InternetExplorerDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://google.com");
	}

	public void homePage(String url) {
		// navigating to the homepage
		driver.get(url);
		System.out.println(driver.getTitle());

	}

	public void login() {
		// entering valid credentials
		driver.findElement(username).sendKeys("Admin");
		driver.findElement(password).sendKeys("admin123");
		WebElement d = driver.findElement(By.id("btnLogin"));
		d.click();
		driver.findElement(DirectoryTab).click();
	}

	public void InvalidSearchOperation() {
		driver.findElement(invalid_name).sendKeys("Lindaa Andersona");
		Select jobTitle = new Select(driver.findElement(By.id("searchDirectory_job_title")));
		jobTitle.selectByVisibleText("Account Clerk");
	}

	public void searchButton() {
		driver.findElement(searchButton).click();
	}

	public void resultsVerifcation() {
		String Actual = driver.findElement(Result).getText();

		Assert.assertTrue("Text not found!", Actual.contains("No Records Found"));
	}

	public void getScreenshot() throws IOException {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("D:\\Selenium\\screenshots\\Invalid.png"));
	}

	public void close() {
		driver.quit();
	}
}
