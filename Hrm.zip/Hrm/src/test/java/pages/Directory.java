package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.apache.commons.io.FileUtils;

public class Directory {
	WebElement textbox;
	WebDriver driver;
	By username = By.id("txtUsername");
	By password = By.id("txtPassword");
	By login = By.id("btnLogin");
	By DirectoryTab = By.xpath("//*[@id=\"menu_directory_viewDirectory\"]/b");

	public void browserLaunch(String browser) {
		// multi browser methods
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("Explorer")) {
			System.setProperty("webdriver.ie.driver", "drivers/ie.exe");
			driver = new InternetExplorerDriver();
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driver.get("https://google.com");
		System.out.println(driver.getTitle());

	}

	public void demoblaze_homePage(String url) {
		driver.get(url);
		System.out.println(driver.getTitle());
	}

	public void login() {
		// entering valid credentials
		driver.findElement(username).sendKeys("Admin");
		driver.findElement(password).sendKeys("admin123");
		WebElement d = driver.findElement(By.id("btnLogin"));
		d.click();
	}

	public void DirectoryTab() {
		driver.findElement(DirectoryTab).click();

	}

	public void DirectoryTabValidation() throws IOException {

		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("D:\\Selenium\\screenshots\\DirectoryTab.png.png"));
	}

	public void close() {
		driver.quit();
	}
}
