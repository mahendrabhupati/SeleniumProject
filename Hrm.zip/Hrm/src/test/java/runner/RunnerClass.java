package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\main\\resources\\feature folder\\orange.feature",
tags= {"@Tc_1,@Tc_2,@Tc_3,@Tc_4,@Tc_5"},
glue= {"stepDefinitions"},
monochrome=true
)
public class RunnerClass {

}
