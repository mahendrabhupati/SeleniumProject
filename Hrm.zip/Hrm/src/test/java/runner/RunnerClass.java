package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\main\\resources\\feature folder\\feature.feature",
tags= {"@Tc_1,@Tc_2,@Tc_3,@Tc_4,@Tc_5"},
glue= {"stepDefinitions"},
monochrome=true,
plugin = {"pretty", "html:reports/cucumber-html-report","jason:reports/cucumber-html-report/jasonreport","com.cucumber.listener.ExtentCucumberFormatter:reports/Extentreport.html"}
)
public class RunnerClass {

	@AfterClass
	public static void extentReport() {
		Reporter.loadXMLConfig("src/test/resources/extent-config.xml");
		Reporter.setSystemInfo("user Name", System.getProperty("user.name"));
		Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		Reporter.setSystemInfo("Machine", "Windows 10" +"64 Bit");
		Reporter.setSystemInfo("Selenium", "3.141.59");
		Reporter.setSystemInfo("Maven", "4.0.0");
		Reporter.setSystemInfo("Java Version", "1.8.0_131");
	}
}
