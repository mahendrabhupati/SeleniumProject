package stepDefinition;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.LogIn;

public class Login_SD {

	
	LogIn lg = new LogIn();

	@Given("^the user launched the chromebrowser$")
	public void the_user_launched_the_chromebrowser() throws Throwable {
		lg.browserLaunch("chrome");
	}

	@When("^the user open the Demoblaze website$")
	public void the_user_open_the_Demoblaze_website() {
		lg.demoblaze_homePage("https://opensource-demo.orangehrmlive.com/");
	}

	@Then("^the user enters the username and password$")
	public void the_user_enters_the_username_and_password() throws IOException, InterruptedException {
			lg.login();
		}

	@Then("^user clicks on login button$")
	public void user_clicks_on_login_button() throws IOException {
		lg.userclick();
		lg.close();
	}

}