package excelUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ValidExcelUtility {

	public String excel_username(int a) throws IOException {

		FileInputStream fil = new FileInputStream(new File("TestData//TestData.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		String username = sheet.getRow(a).getCell(0).getStringCellValue();

		return username;
	}

	public String excel_password(int b) throws IOException {

		FileInputStream fil = new FileInputStream(new File("TestData//TestData.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(fil);
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		String password = sheet.getRow(b).getCell(1).getStringCellValue();

		return password;
	}
}
