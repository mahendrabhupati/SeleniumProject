package pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import excelUtility.ValidExcelUtility;

public class DirectoryTab {
	WebDriver driverObj;
	ValidExcelUtility obj = new ValidExcelUtility();
	By Username = By.id("txtUsername");
	By Password = By.id("txtPassword");
	By driverTab = By.id("menu_directory_viewDirectory");
	By verifyText = By.xpath("//*[@id=\"content\"]/div[1]/a");

	public void browserLaunch(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
			driverObj = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("Explorer")) {
			System.setProperty("webdriver.ie.driver", "drivers/ie.exe");
			driverObj = new InternetExplorerDriver();
		}

		driverObj.manage().window().maximize();
		driverObj.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		driverObj.get("https://google.com");
		System.out.println(driverObj.getTitle());

	}

	public void homePage(String url) {
		driverObj.get(url);
	}

	public void login() {

		driverObj.findElement(Username).sendKeys("Admin");
		driverObj.findElement(Password).sendKeys("admin123");
		WebElement d = driverObj.findElement(By.id("btnLogin"));
		d.click();
	}

	public void DriverTab() {
		driverObj.findElement(driverTab).click();

	}

	//public boolean verify() {
	//	return driverObj.findElement(verifyText).isDisplayed();
	//}

	public void close() {
		driverObj.quit();
	}
}
