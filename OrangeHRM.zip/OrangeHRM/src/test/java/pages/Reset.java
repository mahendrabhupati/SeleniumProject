package pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import excelUtility.ValidExcelUtility;



public class Reset {
	protected WebDriver driverObj;
	By Username = By.xpath("//*[@id=\"divUsername\"]/span");
	By Password = By.xpath("//*[@id=\"divPassword\"]/span");
	By driverTab = By.xpath("//*[@id=\"menu_directory_viewDirectory\"]/b");
	By searchInput = By.xpath("//*[@id=\"searchDirectory_emp_name_empName\"]");
	By ResetButton = By.xpath("//*[@id=\"resetBtn\"]");
	ValidExcelUtility obj =new ValidExcelUtility();
	public void browserLaunch() {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		driverObj = new ChromeDriver();
		driverObj.manage().window().maximize();
		driverObj.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driverObj.get("www.google.com");
	}

	public void homePage(String url) {
		driverObj.get(url);
	}

	public void login() {

		driverObj.findElement(By.id("Username")).sendKeys("Admin");
		driverObj.findElement(By.id("Password")).sendKeys("admin123");
		WebElement d = driverObj.findElement(By.xpath("//*[@id=\"logInModal\"]//div//div//div[3]//button[2]"));
		d.click();
	}
	public void ResetMethod() {
		driverObj.findElement(driverTab).click();
		driverObj.findElement(searchInput).sendKeys("mahendra");
		driverObj.findElement(ResetButton).click();
	}

	public void close() {
		driverObj.quit();
	}
}
