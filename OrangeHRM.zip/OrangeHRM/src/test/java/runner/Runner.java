package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/main/java/feature/Hrm.feature",
plugin = {"pretty","html:reports/cucumber-html-report"},
tags= {"@Tc_1,@Tc_2,@Tc_3,@Tc_4,@Tc_5"},
glue= {"steps"},
monochrome=true
)
public class Runner {

}
